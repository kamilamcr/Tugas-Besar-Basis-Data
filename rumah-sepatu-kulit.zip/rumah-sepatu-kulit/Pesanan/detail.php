<?php
require_once '../db.php';

// PASTIKAN no_pesanan ADA DI URL
if (!isset($_GET['no'])) {
    die("Nomor pesanan tidak diberikan.");
}
$no_pesanan = $_GET['no'];


// BAGIAN UNTUK MEMPROSES FORM SAAT DISUBMIT (METHOD POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal_transaksi = $_POST['tanggal_transaksi'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $jumlah_bayar = $_POST['jumlah_bayar'];
    $status = $_POST['status'];

    try {
        $stmt = $pdo->prepare("INSERT INTO transaksi (no_pesanan, tanggal_transaksi, metode_pembayaran, jumlah_bayar, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$no_pesanan, $tanggal_transaksi, $metode_pembayaran, $jumlah_bayar, $status]);

        header('Location: detail.php?no=' . $no_pesanan);
        exit;
    } catch (PDOException $e) {
        die("Gagal menyimpan transaksi: " . $e->getMessage());
    }
}


// BAGIAN UNTUK MENAMPILKAN DATA (METHOD GET)
// 1. Ambil data pesanan utama (TERMASUK NAMA KASIR)
$stmt = $pdo->prepare("
    SELECT 
        p.no_pesanan, p.tanggal_pesanan, p.status_produksi, p.status_pengiriman, 
        pel.nama_pelanggan,
        k.nama_kasir
    FROM 
        pesanan p
    JOIN 
        pelanggan pel ON p.id_pelanggan = pel.id_pelanggan
    LEFT JOIN                           -- Menggunakan LEFT JOIN ke tabel kasir
        kasir k ON p.id_kasir = k.id_kasir
    WHERE 
        p.no_pesanan = ?
");
$stmt->execute([$no_pesanan]);
$pesanan = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$pesanan) {
    die("Pesanan tidak ditemukan.");
}

// 2. Ambil detail item pesanan
$stmt = $pdo->prepare("SELECT dp.warna, dp.ukuran, dp.quantity, pr.model_sepatu, pr.harga, (dp.quantity * pr.harga) AS sub_total FROM detail_pesanan dp JOIN produk pr ON dp.kode_model_sepatu = pr.kode_model_sepatu WHERE dp.no_pesanan = ?");
$stmt->execute([$no_pesanan]);
$detail_pesanan = $stmt->fetchAll(PDO::FETCH_ASSOC);
$total_pesanan = array_sum(array_column($detail_pesanan, 'sub_total'));

// 3. Ambil riwayat transaksi
$transaksi_stmt = $pdo->prepare("SELECT * FROM transaksi WHERE no_pesanan = ? ORDER BY tanggal_transaksi DESC");
$transaksi_stmt->execute([$no_pesanan]);
$riwayat_transaksi = $transaksi_stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pesanan</title>
    <style>
        html { height: 100%; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4e1d2; margin: 0; padding: 2rem 0; display: flex; flex-direction: column; min-height: 100%; }
        header { background-color: #5a3e2b; color: #fff; padding: 1rem; text-align: center; }
        .container { max-width: 800px; margin: 2rem auto; padding: 1.5rem; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; margin-bottom: 2rem; }
        table, th, td { border: 1px solid #ccc; }
        th, td { padding: 0.75rem; text-align: left; }
        th { background-color: #f4e1d2; }
        tfoot td { font-weight: bold; }
        .btn, .btn-back { display: inline-block; padding: 0.75rem 1rem; border-radius: 4px; font-weight: bold; text-decoration: none; cursor: pointer; border: none; }
        .btn-back { background-color: #5a6268; color: #fff; margin-bottom: 1rem; }
        .btn-back:hover { background-color: #4a5056; }
        .btn-tambah { background-color: #28a745; color: white; margin-bottom: 1rem; }
        .btn-tambah:hover { background-color: #218838; }
        footer { text-align: center; padding: 1rem 0; background-color: #5a3e2b; color: #fff; margin-top: auto; }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.5); }
        .modal-content { background-color: #fefefe; margin: 10% auto; padding: 2rem; border: 1px solid #888; width: 80%; max-width: 500px; border-radius: 8px; position: relative; }
        .close-button { color: #aaa; float: right; font-size: 28px; font-weight: bold; }
        .close-button:hover, .close-button:focus { color: black; text-decoration: none; cursor: pointer; }
        .modal-content label { display: block; margin-bottom: 0.5rem; font-weight: bold; }
        .modal-content input, .modal-content select, .modal-content button { width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 4px; font-size: 1rem; box-sizing: border-box; }
        .modal-content button { background-color: #28a745; color: white; border: none; }
    </style>
</head>
<body>
    <header>
        <h1>Detail Pesanan: <?= htmlspecialchars($no_pesanan) ?></h1>
    </header>
    <div class="container">
        <a href="index.php" class="btn btn-back">Kembali ke Daftar Pesanan</a>
        
        <h3>Informasi Pesanan</h3>
        <p><strong>Dicatat oleh:</strong> <?= htmlspecialchars($pesanan['nama_kasir'] ?? 'N/A') ?></p>
        <p><strong>Status Produksi:</strong> <?= htmlspecialchars($pesanan['status_produksi']) ?></p>
        <p><strong>Status Pengiriman:</strong> <?= htmlspecialchars($pesanan['status_pengiriman']) ?></p>
        
        <h3>Rincian Item</h3>
        <table>
            <thead>
                <tr>
                    <th>Model Sepatu</th>
                    <th>Warna</th>
                    <th>Ukuran</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Sub Total</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($detail_pesanan)): ?>
                    <?php foreach ($detail_pesanan as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['model_sepatu']) ?></td>
                            <td><?= htmlspecialchars($item['warna']) ?></td>
                            <td><?= htmlspecialchars($item['ukuran']) ?></td>
                            <td><?= htmlspecialchars($item['quantity']) ?></td>
                            <td>Rp <?= htmlspecialchars(number_format($item['harga'], 0, ',', '.')) ?></td>
                            <td>Rp <?= htmlspecialchars(number_format($item['sub_total'], 0, ',', '.')) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">Tidak ada item dalam pesanan ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" style="text-align: right;"><strong>Total Pesanan</strong></td>
                    <td><strong>Rp <?= htmlspecialchars(number_format($total_pesanan, 0, ',', '.')) ?></strong></td>
                </tr>
            </tfoot>
        </table>

        <button id="bukaModalBtn" class="btn btn-tambah">+ Catat Pembayaran Baru</button>

        <h3>Riwayat Pembayaran / Transaksi</h3>
        <table>
            <thead>
                <tr>
                    <th>ID Transaksi</th>
                    <th>Tanggal</th>
                    <th>Metode Pembayaran</th>
                    <th>Jumlah Bayar</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($riwayat_transaksi)): ?>
                    <?php foreach ($riwayat_transaksi as $transaksi): ?>
                        <tr>
                            <td><?= htmlspecialchars($transaksi['id_transaksi']) ?></td>
                            <td><?= htmlspecialchars($transaksi['tanggal_transaksi']) ?></td>
                            <td><?= htmlspecialchars($transaksi['metode_pembayaran']) ?></td>
                            <td>Rp <?= htmlspecialchars(number_format($transaksi['jumlah_bayar'], 0, ',', '.')) ?></td>
                            <td><?= htmlspecialchars($transaksi['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">Belum ada riwayat transaksi untuk pesanan ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <div id="transaksiModal" class="modal">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h2>Tambah Transaksi untuk Pesanan #<?= htmlspecialchars($no_pesanan) ?></h2>
            <form method="POST" action="">
                <p>Total Tagihan: <strong>Rp <?= number_format($total_pesanan, 0, ',', '.') ?></strong></p>
            
                <label for="tanggal_transaksi">Tanggal Transaksi</label>
                <input type="date" id="tanggal_transaksi" name="tanggal_transaksi" value="<?= date('Y-m-d') ?>" required>

                <label for="metode_pembayaran">Metode Pembayaran</label>
                <input type="text" id="metode_pembayaran" name="metode_pembayaran" placeholder="Contoh: Transfer Bank, Tunai" required>

                <label for="jumlah_bayar">Jumlah Bayar</label>
                <input type="number" id="jumlah_bayar" name="jumlah_bayar" value="<?= $total_pesanan ?>" required>

                <label for="status">Status Transaksi</label>
                <select id="status" name="status" required>
                    <option value="Lunas">Lunas</option>
                    <option value="Belum Lunas">Belum Lunas</option>
                </select>

                <button type="submit">Simpan Transaksi</button>
            </form>
        </div>
    </div>

    <footer>
        &copy; 2025 Rumah Produksi "T-DEE". All Rights Reserved.
    </footer>

    <script>
        var modal = document.getElementById("transaksiModal");
        var btnBuka = document.getElementById("bukaModalBtn");
        var spanTutup = document.getElementsByClassName("close-button")[0];

        btnBuka.onclick = function() {
            modal.style.display = "block";
        }

        spanTutup.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>
</html>