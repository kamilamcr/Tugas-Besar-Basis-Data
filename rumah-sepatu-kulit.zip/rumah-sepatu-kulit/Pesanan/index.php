<?php
require_once '../db.php';

// Ambil data pesanan dari database
$stmt = $pdo->query("SELECT p.no_pesanan, p.tanggal_pesanan, pel.nama_pelanggan 
                      FROM pesanan p
                      JOIN pelanggan pel ON p.id_pelanggan = pel.id_pelanggan
                      ORDER BY p.tanggal_pesanan DESC");
$pesanan = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pesanan</title>
    <style>
        html { height: 100%; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4e1d2; margin: 0; padding: 0; display: flex; flex-direction: column; min-height: 100%; }
        header { background-color: #5a3e2b; color: #fff; padding: 1rem; text-align: center; }
        header h1 { margin: 0; }
        .container { max-width: 1000px; margin: 2rem auto; padding: 1rem; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        table, th, td { border: 1px solid #ccc; }
        th, td { padding: 0.75rem; text-align: left; }
        th { background-color: #f4e1d2; }

        /* Base style untuk semua tombol */
        .btn { display: inline-block; padding: 0.5rem 1rem; text-decoration: none; border-radius: 4px; font-weight: bold; margin-bottom: 0.5rem; margin-right: 0.5rem; border: none; cursor: pointer; text-align: center;}
        
        /* Warna Coklat Muda untuk tombol utama */
        .btn-tambah, .btn-detail, .btn-edit, .btn-hapus { 
            background-color: #d9b08c; 
            color: #5a3e2b; 
        }
        
        /* Hover effect untuk tombol coklat muda */
        .btn-tambah:hover, .btn-detail:hover, .btn-edit:hover, .btn-hapus:hover {
            background-color: #c4977a;
        }

        /* Warna Abu-abu untuk tombol kembali */
        .btn-back { 
            background-color: #5a6268; 
            color: white; 
        }
        .btn-back:hover {
            background-color: #4a5056;
        }
        
        footer { text-align: center; padding: 1rem 0; background-color: #5a3e2b; color: #fff; margin-top: auto; }
    </style>
</head>
<body>
    <header>
        <h1>Daftar Pesanan</h1>
    </header>
    <div class="container">
        <a href="create.php" class="btn btn-tambah">Tambah Pesanan Baru</a>
        <a href="../index.php" class="btn btn-back">Kembali ke Dashboard</a>
        <table>
            <thead>
                <tr>
                    <th>No Pesanan</th>
                    <th>Nama Pelanggan</th>
                    <th>Tanggal Pesanan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($pesanan)): ?>
                    <?php foreach ($pesanan as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['no_pesanan']) ?></td>
                            <td><?= htmlspecialchars($row['nama_pelanggan']) ?></td>
                            <td><?= htmlspecialchars($row['tanggal_pesanan']) ?></td>
                            <td>
                                <a href="detail.php?no=<?= htmlspecialchars($row['no_pesanan']) ?>" class="btn btn-detail">Detail</a>
                                <a href="edit.php?no=<?= htmlspecialchars($row['no_pesanan']) ?>" class="btn btn-edit">Edit</a>
                                <a href="delete.php?no=<?= htmlspecialchars($row['no_pesanan']) ?>" class="btn btn-hapus" onclick="return confirm('PERINGATAN: Menghapus pesanan juga akan menghapus semua detail item di dalamnya. Lanjutkan?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">Tidak ada data pesanan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <footer>
        &copy; 2025 Rumah Produksi "T-DEE". All Rights Reserved.
    </footer>
</body>
</html>