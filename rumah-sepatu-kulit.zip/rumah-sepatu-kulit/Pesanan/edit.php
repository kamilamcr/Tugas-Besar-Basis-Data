<?php
// Bagian PHP tetap sama, tidak ada perubahan
require_once '../db.php';

$no_pesanan = $_GET['no'] ?? null;
if (!$no_pesanan) {
    die("Nomor pesanan tidak ditemukan.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->beginTransaction();
    try {
        // 1. UPDATE DATA UTAMA (PESANAN), TERMASUK ID KASIR
        $stmt_pesanan = $pdo->prepare(
            "UPDATE pesanan SET id_pelanggan = ?, tanggal_pesanan = ?, status_produksi = ?, status_pengiriman = ?, id_kasir = ? 
             WHERE no_pesanan = ?"
        );
        $stmt_pesanan->execute([
            $_POST['id_pelanggan'],
            $_POST['tanggal_pesanan'],
            $_POST['status_produksi'],
            $_POST['status_pengiriman'],
            $_POST['id_kasir'],
            $no_pesanan
        ]);

        // 2. PROSES ITEM DETAIL YANG SUDAH ADA (UPDATE ATAU DELETE)
        if (isset($_POST['id_detail'])) {
            $stmt_update_detail = $pdo->prepare("UPDATE detail_pesanan SET kode_model_sepatu = ?, warna = ?, ukuran = ?, quantity = ? WHERE id_detail = ?");
            $stmt_delete_detail = $pdo->prepare("DELETE FROM detail_pesanan WHERE id_detail = ?");

            foreach ($_POST['id_detail'] as $index => $id) {
                if (isset($_POST['hapus_detail']) && in_array($id, $_POST['hapus_detail'])) {
                    $stmt_delete_detail->execute([$id]);
                } else {
                    $stmt_update_detail->execute([
                        $_POST['kode_model_sepatu'][$index],
                        $_POST['warna'][$index],
                        $_POST['ukuran'][$index],
                        $_POST['quantity'][$index],
                        $id
                    ]);
                }
            }
        }

        // 3. PROSES ITEM DETAIL BARU (INSERT)
        if (isset($_POST['new_kode_model_sepatu'])) {
            $stmt_insert_detail = $pdo->prepare("INSERT INTO detail_pesanan (no_pesanan, kode_model_sepatu, warna, ukuran, quantity) VALUES (?, ?, ?, ?, ?)");
            foreach ($_POST['new_kode_model_sepatu'] as $index => $kode_baru) {
                if (!empty($kode_baru) && !empty($_POST['new_quantity'][$index])) {
                    $stmt_insert_detail->execute([
                        $no_pesanan,
                        $kode_baru,
                        $_POST['new_warna'][$index],
                        $_POST['new_ukuran'][$index],
                        $_POST['new_quantity'][$index]
                    ]);
                }
            }
        }
        
        $pdo->commit();
        header('Location: index.php');
        exit;

    } catch (PDOException $e) {
        $pdo->rollBack();
        die("Gagal mengupdate data: " . $e->getMessage());
    }
}

// Ambil data pesanan yang akan diedit
$stmt = $pdo->prepare("SELECT * FROM pesanan WHERE no_pesanan = ?");
$stmt->execute([$no_pesanan]);
$pesanan = $stmt->fetch(PDO::FETCH_ASSOC);

// Ambil detail item yang sudah ada
$detail_items_stmt = $pdo->prepare("SELECT * FROM detail_pesanan WHERE no_pesanan = ?");
$detail_items_stmt->execute([$no_pesanan]);
$detail_items = $detail_items_stmt->fetchAll(PDO::FETCH_ASSOC);

// Ambil daftar master data untuk dropdown
$pelanggan_list = $pdo->query("SELECT id_pelanggan, nama_pelanggan FROM pelanggan")->fetchAll(PDO::FETCH_ASSOC);
$produk_list = $pdo->query("SELECT kode_model_sepatu, model_sepatu FROM produk")->fetchAll(PDO::FETCH_ASSOC);
$kasir_list = $pdo->query("SELECT id_kasir, nama_kasir FROM kasir ORDER BY nama_kasir ASC")->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pesanan</title>
    <style>
        html { height: 100%; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4e1d2; margin: 0; padding: 2rem 0; display: flex; flex-direction: column; min-height: 100%; }
        .container { max-width: 1000px; margin: 2rem auto; padding: 1.5rem; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        header { background-color: #5a3e2b; color: #fff; padding: 1rem; text-align: center; }
        label { display: block; margin-bottom: 0.5rem; font-weight: bold; }
        input, select { width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 4px; font-size: 1rem; box-sizing: border-box; }
        
        /* === PERUBAHAN CSS UNTUK TOMBOL === */
        .btn-container { 
            display: flex; 
            gap: 1rem; 
            margin-top: 1rem;
        }
        .btn-update, .btn-back {
            flex: 1; /* KUNCI: Membuat kedua tombol memiliki lebar yang sama */
            padding: 0.75rem;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            text-align: center;
            text-decoration: none;
        }
        .btn-update {
            background-color: #ffc107; /* Warna kuning untuk update */
            color: black;
        }
        .btn-update:hover {
            opacity: 0.85;
        }
        .btn-back {
            background-color: #5a6268;
            color: white;
        }
        .btn-back:hover {
            opacity: 0.85;
        }

        hr { border: 0; height: 1px; background-color: #eee; margin: 2rem 0; }
        .detail-item-row { display: flex; gap: 0.75rem; align-items: center; margin-bottom: 0.75rem; padding-bottom: 0.75rem; border-bottom: 1px solid #f0f0f0; }
        .detail-item-row > * { margin-bottom: 0; }
        .detail-item-row select[name*="kode_model_sepatu"] { flex: 3; }
        .detail-item-row input[name*="warna"] { flex: 2; }
        .detail-item-row input[name*="ukuran"], .detail-item-row input[name*="quantity"] { flex: 1; }
        .delete-box { display: flex; align-items: center; justify-content: center; gap: 0.3rem; flex: 1; white-space: nowrap; }
        .delete-box input[type="checkbox"] { width: auto; }
        .btn-add { width: auto; background-color: #28a745; color: white; padding: 0.5rem 1rem; font-weight: bold; cursor: pointer; margin-top: 0.5rem; border-radius: 4px; border: none; }
        footer { text-align: center; padding: 1rem 0; background-color: #5a3e2b; color: #fff; margin-top: auto; }
    </style>
</head>
<body>
    <header><h1>Edit Pesanan: <?= htmlspecialchars($pesanan['no_pesanan']) ?></h1></header>
    <div class="container">
        <form method="POST">
            <h3>Informasi Utama</h3>
            <label for="id_pelanggan">Pelanggan</label>
            <select id="id_pelanggan" name="id_pelanggan" required>
                <?php foreach ($pelanggan_list as $pelanggan): ?>
                    <option value="<?= htmlspecialchars($pelanggan['id_pelanggan']) ?>" <?= ($pelanggan['id_pelanggan'] == $pesanan['id_pelanggan']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($pelanggan['nama_pelanggan']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <label for="id_kasir">Dicatat oleh Kasir</label>
            <select id="id_kasir" name="id_kasir" required>
                <?php foreach ($kasir_list as $kasir): ?>
                    <option value="<?= htmlspecialchars($kasir['id_kasir']) ?>" <?= ($kasir['id_kasir'] == $pesanan['id_kasir']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($kasir['nama_kasir']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <label for="tanggal_pesanan">Tanggal Pesanan</label>
            <input type="date" id="tanggal_pesanan" name="tanggal_pesanan" value="<?= htmlspecialchars($pesanan['tanggal_pesanan']) ?>" required>
            <label for="status_produksi">Status Produksi</label>
            <input type="text" id="status_produksi" name="status_produksi" value="<?= htmlspecialchars($pesanan['status_produksi']) ?>" required>
            <label for="status_pengiriman">Status Pengiriman</label>
            <select id="status_pengiriman" name="status_pengiriman" required>
                <option value="Dikemas" <?= ($pesanan['status_pengiriman'] == 'Dikemas') ? 'selected' : '' ?>>Dikemas</option>
                <option value="Dikirim" <?= ($pesanan['status_pengiriman'] == 'Dikirim') ? 'selected' : '' ?>>Dikirim</option>
                <option value="Diterima" <?= ($pesanan['status_pengiriman'] == 'Diterima') ? 'selected' : '' ?>>Diterima</option>
            </select>

            <hr>

            <h3>Detail Item Pesanan</h3>
            <div id="detail-items-list">
                <?php foreach ($detail_items as $item): ?>
                    <div class="detail-item-row">
                        <input type="hidden" name="id_detail[]" value="<?= $item['id_detail'] ?>">
                        <select name="kode_model_sepatu[]" required>
                            <?php foreach ($produk_list as $produk): ?>
                                <option value="<?= htmlspecialchars($produk['kode_model_sepatu']) ?>" <?= ($produk['kode_model_sepatu'] == $item['kode_model_sepatu']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($produk['model_sepatu']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="warna[]" value="<?= htmlspecialchars($item['warna']) ?>" placeholder="Warna" required>
                        <input type="number" name="ukuran[]" value="<?= htmlspecialchars($item['ukuran']) ?>" placeholder="Ukuran" required>
                        <input type="number" name="quantity[]" value="<?= htmlspecialchars($item['quantity']) ?>" placeholder="Qty" min="1" required>
                        <div class="delete-box">
                            <input type="checkbox" name="hapus_detail[]" value="<?= $item['id_detail'] ?>" title="Centang untuk menghapus item ini">
                            <label>Hapus</label>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="btn-add" onclick="tambahItemBaru()">+ Tambah Item Baru</button>

            <hr>
            
            <div class="btn-container">
                <a href="index.php" class="btn-back">Kembali</a>
                <button type="submit" class="btn-update">Update Pesanan</button>
            </div>
        </form>
    </div>
    <footer>
        &copy; 2025 Rumah Produksi "T-DEE". All Rights Reserved.
    </footer>

    <script>
        function tambahItemBaru() {
            const list = document.getElementById('detail-items-list');
            const newRow = document.createElement('div');
            newRow.className = 'detail-item-row';
            const produkOptions = `<?php foreach ($produk_list as $produk) { echo "<option value=\\\"".htmlspecialchars($produk['kode_model_sepatu'])."\\\">".htmlspecialchars($produk['model_sepatu'])."</option>"; } ?>`;
            
            newRow.innerHTML = `
                <select name="new_kode_model_sepatu[]" required>
                    <option value="">Pilih Produk</option>
                    ${produkOptions}
                </select>
                <input type="text" name="new_warna[]" placeholder="Warna" required>
                <input type="number" name="new_ukuran[]" placeholder="Ukuran" required>
                <input type="number" name="new_quantity[]" placeholder="Qty" min="1" required>
                <div style="flex: 1;"></div> 
            `;
            list.appendChild(newRow);
        }
    </script>
</body>
</html>