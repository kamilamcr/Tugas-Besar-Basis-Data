<?php
require_once '../db.php';

// Ambil daftar data master untuk dropdown
try {
    $pelanggan_list = $pdo->query("SELECT id_pelanggan, nama_pelanggan FROM pelanggan")->fetchAll(PDO::FETCH_ASSOC);
    $produk_list = $pdo->query("SELECT kode_model_sepatu, model_sepatu FROM produk")->fetchAll(PDO::FETCH_ASSOC);
    // PENAMBAHAN: Ambil daftar kasir dari database
    $kasir_list = $pdo->query("SELECT id_kasir, nama_kasir FROM kasir ORDER BY nama_kasir ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Gagal mengambil data master: " . $e->getMessage());
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Data dari "kepala" pesanan
    $no_pesanan = $_POST['no_pesanan'];
    $id_pelanggan = $_POST['id_pelanggan'];
    $id_kasir = $_POST['id_kasir']; // <-- PENAMBAHAN: Ambil ID Kasir dari form
    $tanggal_pesanan = $_POST['tanggal_pesanan'];
    $status_produksi = 'Dalam Produksi';
    $status_pengiriman = 'Dikemas';

    // Data dari "detail" pesanan (array)
    $produk_ids = $_POST['produk_id'];
    $warnas = $_POST['warna'];
    $ukurans = $_POST['ukuran'];
    $quantities = $_POST['quantity'];

    $pdo->beginTransaction();
    try {
        // PENAMBAHAN: Query INSERT sekarang menyertakan id_kasir
        $stmt_pesanan = $pdo->prepare(
            "INSERT INTO pesanan (no_pesanan, id_pelanggan, id_kasir, tanggal_pesanan, status_produksi, status_pengiriman) 
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt_pesanan->execute([$no_pesanan, $id_pelanggan, $id_kasir, $tanggal_pesanan, $status_produksi, $status_pengiriman]);

        // Bagian ini tidak berubah
        $stmt_detail = $pdo->prepare("INSERT INTO detail_pesanan (no_pesanan, kode_model_sepatu, warna, ukuran, quantity) VALUES (?, ?, ?, ?, ?)");
        foreach ($produk_ids as $index => $produk_id) {
            if (!empty($produk_id) && !empty($quantities[$index])) {
                $stmt_detail->execute([$no_pesanan, $produk_id, $warnas[$index], $ukurans[$index], $quantities[$index]]);
            }
        }

        $pdo->commit();
        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        $pdo->rollBack();
        die("Terjadi kesalahan saat menyimpan pesanan: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Pesanan Baru</title>
    <style>
        html { height: 100%; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4e1d2; margin: 0; padding: 0; display: flex; flex-direction: column; min-height: 100%; }
        header { background-color: #5a3e2b; color: #fff; padding: 1rem; text-align: center; }
        header h1 { margin: 0; }
        .container { max-width: 800px; margin: 2rem auto; padding: 1.5rem; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        label { display: block; margin-bottom: 0.5rem; font-weight: bold; }
        input, select { width: 100%; padding: 0.75rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 4px; font-size: 1rem; box-sizing: border-box; }
        .btn-container { display: flex; gap: 1rem; margin-top: 1.5rem; }
        .btn-submit, .btn-back { flex: 1; padding: 0.75rem; font-weight: bold; cursor: pointer; border-radius: 4px; text-decoration: none; text-align: center; border: none; font-size: 1rem; }
        .btn-submit { background-color: #d9b08c; color: #5a3e2b; }
        .btn-back { background-color: #5a6268; color: #fff; }
        hr { border: 0; height: 1px; background-color: #eee; margin: 2rem 0; }
        .produk-row { display: flex; gap: 0.5rem; align-items: center; margin-bottom: 0.5rem; padding-bottom: 0.5rem; border-bottom: 1px solid #eee; }
        .produk-row > * { margin-bottom: 0; }
        .produk-row select { flex: 3; }
        .produk-row input { flex: 2; }
        .btn-add { display: inline-block; width: auto; background-color: #28a745; color: white; padding: 0.5rem 1rem; border: none; font-weight: bold; cursor: pointer; border-radius: 4px; }
        .btn-remove { display: inline-block; width: auto; background-color: #dc3545; color: white; padding: 0.5rem; border: none; font-size: 0.8rem; font-weight: bold; cursor: pointer; border-radius: 4px;}
        footer { text-align: center; padding: 1rem 0; background-color: #5a3e2b; color: #fff; margin-top: auto; }
    </style>
</head>
<body>
    <header><h1>Buat Pesanan Baru</h1></header>
    <div class="container">
        <form method="POST">
            <h3>Informasi Pesanan</h3>
            <label for="no_pesanan">No Pesanan</label>
            <input type="text" id="no_pesanan" name="no_pesanan" required>

            <label for="id_pelanggan">Pelanggan</label>
            <select id="id_pelanggan" name="id_pelanggan" required>
                <option value="">Pilih Pelanggan</option>
                <?php foreach ($pelanggan_list as $pelanggan): ?>
                    <option value="<?= htmlspecialchars($pelanggan['id_pelanggan']) ?>"><?= htmlspecialchars($pelanggan['nama_pelanggan']) ?></option>
                <?php endforeach; ?>
            </select>
            
            <label for="id_kasir">Dicatat oleh Kasir</label>
            <select id="id_kasir" name="id_kasir" required>
                <option value="">Pilih Nama Kasir</option>
                <?php foreach ($kasir_list as $kasir): ?>
                    <option value="<?= htmlspecialchars($kasir['id_kasir']) ?>"><?= htmlspecialchars($kasir['nama_kasir']) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="tanggal_pesanan">Tanggal Pesanan</label>
            <input type="date" id="tanggal_pesanan" name="tanggal_pesanan" value="<?= date('Y-m-d') ?>" required>

            <hr>
            <h3>Detail Produk</h3>
            <div id="produk-list"></div>
            <button type="button" class="btn-add" onclick="tambahProduk()">+ Tambah Produk</button>
            
            <div class="btn-container">
                <a href="index.php" class="btn-back">Kembali</a>
                <button type="submit" class="btn-submit">Simpan Pesanan</button>
            </div>
        </form>
    </div>
    <footer><p>&copy; 2025 Rumah Produksi "T-DEE". All Rights Reserved.</p></footer>

    <script>
        function tambahProduk() {
            const list = document.getElementById('produk-list');
            const row = document.createElement('div');
            row.className = 'produk-row';
            row.innerHTML = `
                <select name="produk_id[]" required>
                    <option value="">Pilih Produk</option>
                    <?php foreach ($produk_list as $produk): ?>
                        <option value="<?= htmlspecialchars($produk['kode_model_sepatu']) ?>"><?= htmlspecialchars($produk['model_sepatu']) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" name="warna[]" placeholder="Warna" required>
                <input type="number" name="ukuran[]" placeholder="Ukuran" required>
                <input type="number" name="quantity[]" placeholder="Qty" min="1" required>
                <button type="button" class="btn-remove" onclick="hapusProduk(this)">X</button>
            `;
            list.appendChild(row);
        }
        function hapusProduk(button) { button.parentElement.remove(); }
        document.addEventListener('DOMContentLoaded', function() { tambahProduk(); });
    </script>
</body>
</html>