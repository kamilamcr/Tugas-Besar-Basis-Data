<?php
require_once '../db.php';

$no_pesanan = $_GET['no'] ?? null;
if (!$no_pesanan) {
    // Jika tidak ada nomor pesanan, kembali ke halaman utama
    header('Location: index.php');
    exit;
}

// Gunakan transaction untuk memastikan kedua operasi (hapus detail & hapus pesanan) berhasil
$pdo->beginTransaction();

try {
    // LANGKAH 1: Hapus semua baris di 'detail_pesanan' yang terkait dengan no_pesanan ini.
    // Ini PENTING untuk dilakukan terlebih dahulu karena ada Foreign Key Constraint.
    $stmt_detail = $pdo->prepare("DELETE FROM detail_pesanan WHERE no_pesanan = ?");
    $stmt_detail->execute([$no_pesanan]);

    // LANGKAH 2: Setelah detailnya terhapus, baru hapus data pesanan utama di tabel 'pesanan'.
    $stmt_pesanan = $pdo->prepare("DELETE FROM pesanan WHERE no_pesanan = ?");
    $stmt_pesanan->execute([$no_pesanan]);

    // Jika semua berhasil, commit transaksi
    $pdo->commit();

    // Kembali ke halaman daftar pesanan
    header('Location: index.php');
    exit;

} catch (PDOException $e) {
    // Jika terjadi error di salah satu langkah, batalkan semua perubahan
    $pdo->rollBack();
    die("Gagal menghapus pesanan: " . $e->getMessage());
}