<?php
// Set header agar outputnya berupa JSON
header('Content-Type: application/json');

require_once '../db.php';

// Pastikan request adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['success' => false, 'message' => 'Metode request tidak valid.']);
    exit;
}

// Ambil data dari form (dengan penambahan tanggal_transaksi)
$no_pesanan = $_POST['no_pesanan'] ?? '';
$tanggal_transaksi = $_POST['tanggal_transaksi'] ?? ''; // <-- Variabel baru
$metode_pembayaran = $_POST['metode_pembayaran'] ?? '';
$jumlah_bayar = $_POST['jumlah_bayar'] ?? 0;
$status = $_POST['status'] ?? '';

// Validasi sederhana (dengan penambahan tanggal_transaksi)
if (empty($no_pesanan) || empty($tanggal_transaksi) || empty($metode_pembayaran) || empty($status)) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Data tidak lengkap.']);
    exit;
}

try {
    // Masukkan data ke tabel transaksi (query diubah untuk menyertakan tanggal)
    $stmt = $pdo->prepare("INSERT INTO transaksi (no_pesanan, tanggal_transaksi, metode_pembayaran, jumlah_bayar, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$no_pesanan, $tanggal_transaksi, $metode_pembayaran, $jumlah_bayar, $status]);

    // Kirim respon sukses
    http_response_code(200); // OK
    echo json_encode(['success' => true, 'message' => 'Transaksi berhasil disimpan.']);

} catch (PDOException $e) {
    // Kirim respon error jika database gagal
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}