<?php
require_once '../db.php';

try {
    // Ambil semua data produk dari database
    $stmt = $pdo->query("SELECT * FROM produk");
    $produk = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Terjadi kesalahan saat mengambil data: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk</title>
    <style>
        html {
            height: 100%;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4e1d2;
            margin: 0;
            padding: 0;
            /* Menjadikan body sebagai flex container */
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }

        header {
            background-color: #5a3e2b;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 1rem;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: #d9b08c;
            color: #5a3e2b;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            margin-bottom: 1rem;
            margin-right: 0.5rem; /* Menambah jarak antar tombol */
        }

        .btn:hover {
            background-color: #c4977a;
        }

        /* Style khusus untuk tombol kembali */
        .btn-back {
            background-color: #5a6268;
            color: white;
        }
        .btn-back:hover {
            background-color: #4a5056;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 0.75rem;
            text-align: left;
        }

        th {
            background-color: #f4e1d2;
        }

        footer {
            text-align: center;
            padding: 1rem 0;
            background-color: #5a3e2b;
            color: #fff;
            /* KUNCI: Mendorong footer ke bawah */
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Daftar Produk</h1>
    </header>
    <div class="container">
        <a href="create.php" class="btn">Tambah Produk</a>
        <!-- Tombol Kembali ke Dashboard ditambahkan di sini -->
        <a href="../index.php" class="btn btn-back">Kembali ke Dashboard</a>
        <table>
            <thead>
                <tr>
                    <th>Kode Model</th>
                    <th>Model Sepatu</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($produk)): ?>
                    <?php foreach ($produk as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['kode_model_sepatu']) ?></td>
                            <td><?= htmlspecialchars($row['model_sepatu']) ?></td>
                            <td><?= htmlspecialchars(number_format($row['harga'], 0, ',', '.')) ?></td>
                            <td>
                                <a href="edit.php?kode=<?= $row['kode_model_sepatu'] ?>" class="btn">Edit</a>
                                <a href="delete.php?kode=<?= $row['kode_model_sepatu'] ?>" class="btn" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <!-- Colspan diubah menjadi 4 karena satu kolom dihilangkan -->
                        <td colspan="4">Tidak ada data produk.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <footer>
        &copy; 2025 Rumah produksi “T-DEE”. All Rights Reserved.
    </footer>
</body>
</html>