<?php
require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode = $_POST['kode_model_sepatu'];
    $model = $_POST['model_sepatu'];
    $harga = $_POST['harga'];

    try {
        // Query INSERT telah diubah, 'jenis_kulit' dihilangkan
        $stmt = $pdo->prepare("INSERT INTO produk (kode_model_sepatu, model_sepatu, harga) VALUES (?, ?, ?)");
        // Variabel '$jenis' dihilangkan dari eksekusi
        $stmt->execute([$kode, $model, $harga]);

        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        die("Terjadi kesalahan: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <style>
        html {
            height: 100%;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4e1d2;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }
        header {
            background-color: #5a3e2b;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }
        header h1 {
            margin: 0;
        }
        .container {
            max-width: 1500px;
            margin: 2rem auto;
            padding: 1.5rem;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 0.75rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
            box-sizing: border-box;
        }
        
        /* === CSS UNTUK TOMBOL === */
        .btn-container {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .btn-submit, .btn-back {
            flex: 1;
            padding: 0.75rem;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: bold;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            border: none;
        }
        .btn-submit {
            background-color: #d9b08c;
            color: #5a3e2b;
        }
        .btn-submit:hover {
            background-color: #c4977a;
        }
        .btn-back {
            background-color: #5a6268;
            color: white;
        }
        .btn-back:hover {
            background-color: #4a5056;
        }
        
        footer {
            text-align: center;
            padding: 1rem 0;
            background-color: #5a3e2b;
            color: #fff;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Tambah Produk</h1>
    </header>
    <div class="container">
        <form method="POST">
            <label for="kode_model_sepatu">Kode Model</label>
            <input type="number" id="kode_model_sepatu" name="kode_model_sepatu" required>

            <label for="model_sepatu">Model Sepatu</label>
            <input type="text" id="model_sepatu" name="model_sepatu" required>

            <label for="harga">Harga</label>
            <input type="number" id="harga" name="harga" required>

            <div class="btn-container">
                <a href="index.php" class="btn-back">Kembali</a>
                <button type="submit" class="btn-submit">Tambah</button>
            </div>
        </form>
    </div>
    <footer>
        &copy; 2025 Rumah produksi “T-DEE”. All Rights Reserved.
    </footer>
</body>
</html>