<?php
require_once '../db.php';

// Ambil data produk berdasarkan kode model
if (isset($_GET['kode'])) {
    $kode = $_GET['kode'];
    $stmt = $pdo->prepare("SELECT * FROM produk WHERE kode_model_sepatu = ?");
    $stmt->execute([$kode]);
    $produk = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$produk) {
        die("Data produk tidak ditemukan.");
    }
} else {
    die("Kode produk tidak diberikan.");
}

// Update data produk
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $model = $_POST['model_sepatu'];
    $harga = $_POST['harga'];

    try {
        // Query UPDATE telah diubah, 'jenis_kulit' dihilangkan
        $stmt = $pdo->prepare("UPDATE produk SET model_sepatu = ?, harga = ? WHERE kode_model_sepatu = ?");
        // Variabel '$jenis' dihilangkan dari eksekusi
        $stmt->execute([$model, $harga, $kode]);

        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        die("Terjadi kesalahan: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <style>
        html {
            height: 100%;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4e1d2;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }
        header {
            background-color: #5a3e2b;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }
        header h1 {
            margin: 0;
        }
        .container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 1.5rem;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 0.75rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
            box-sizing: border-box;
        }
        
        /* === CSS UNTUK TOMBOL === */
        .btn-container {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .btn-update, .btn-back {
            flex: 1;
            padding: 0.75rem;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            text-align: center;
            text-decoration: none;
        }
        .btn-update {
            background-color: #ffc107;
            color: black;
        }
        .btn-update:hover {
            opacity: 0.85;
        }
        .btn-back {
            background-color: #5a6268;
            color: white;
        }
        .btn-back:hover {
            background-color: #4a5056;
        }
        
        footer {
            text-align: center;
            padding: 1rem 0;
            background-color: #5a3e2b;
            color: #fff;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Edit Produk</h1>
    </header>
    <div class="container">
        <form method="POST">
            <label for="model_sepatu">Model Sepatu</label>
            <input type="text" id="model_sepatu" name="model_sepatu" value="<?= htmlspecialchars($produk['model_sepatu']) ?>" required>

            <label for="harga">Harga</label>
            <input type="number" id="harga" name="harga" value="<?= htmlspecialchars($produk['harga']) ?>" required>
            
            <div class="btn-container">
                <a href="index.php" class="btn-back">Kembali</a>
                <button type="submit" class="btn-update">Update</button>
            </div>
        </form>
    </div>
    <footer>
        &copy; 2025 Rumah produksi “T-DEE”. All Rights Reserved.
    </footer>
</body>
</html>