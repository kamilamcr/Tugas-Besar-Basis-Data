<?php
require_once '../db.php';

if (isset($_GET['kode'])) {
    $kode = $_GET['kode'];

    // Hapus data produk berdasarkan kode model
    $stmt = $pdo->prepare("DELETE FROM produk WHERE kode_model_sepatu = ?");
    $stmt->execute([$kode]);

    header('Location: index.php');
    exit;
} else {
    die("Kode produk tidak diberikan.");
}
?>
