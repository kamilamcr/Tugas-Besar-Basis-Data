<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Rumah Sepatu Kulit</title>
    <style>
        html {
            height: 100%;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4e1d2; /* Warna latar belakang krem */
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }

        header {
            background-color: #5a3e2b; /* Warna coklat gelap */
            color: #fff;
            padding: 1.5rem 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5rem;
        }
        
        /* === PERUBAHAN CSS DIMULAI DI SINI === */

        .container {
            max-width: 900px; /* Lebar bisa disesuaikan */
            margin: 2rem auto;
            display: grid;
            /* Diubah untuk membuat 2 kolom yang sama lebar */
            grid-template-columns: repeat(2, 1fr); 
            gap: 2rem; /* Jarak antar tombol diperbesar */
            padding: 1rem;
        }

        .menu-box {
            background-color: #d9b08c; /* Warna coklat muda */
            color: #5a3e2b; /* Warna teks coklat gelap */
            text-align: center;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            /* Padding vertikal diperbesar agar tombol lebih tinggi */
            padding: 4rem 1rem; 
            text-decoration: none;
            /* Ukuran font diperbesar */
            font-size: 1.5rem; 
            font-weight: bold;
            transition: all 0.3s ease-in-out;
            display: flex; /* Tambahan untuk vertical centering */
            align-items: center; /* Tambahan untuk vertical centering */
            justify-content: center; /* Tambahan untuk horizontal centering */
        }

        /* === PERUBAHAN CSS SELESAI === */

        .menu-box:hover {
            background-color: #c4977a; /* Warna coklat lebih gelap saat di-hover */
            transform: translateY(-5px);
        }

        /* Tambahan untuk responsif di layar kecil */
        @media (max-width: 600px) {
            .container {
                /* Kembali menjadi 1 kolom di layar kecil */
                grid-template-columns: 1fr;
            }
        }

        footer {
            text-align: center;
            padding: 1rem 0;
            background-color: #5a3e2b; /* Warna coklat gelap */
            color: #fff;
            margin-top: auto; 
        }
    </style>
</head>
<body>
    <header>
        <h1>Dashboard Rumah produksi “T-DEE”</h1>
    </header>
<div class="container">
        <a href="pelanggan/index.php" class="menu-box">Kelola Pelanggan</a>
        <a href="produk/index.php" class="menu-box">Kelola Produk</a>
        <a href="pesanan/index.php" class="menu-box">Kelola Pesanan</a>
        <a href="transaksi/index.php" class="menu-box">Laporan Transaksi</a>
    </div>
    <footer>
        &copy; 2025 Rumah produksi “T-DEE”. All Rights Reserved.
    </footer>
</body>
</html>