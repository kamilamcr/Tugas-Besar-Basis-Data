<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pelanggan</title>
    <style>
        html {
            height: 100%;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4e1d2;
            margin: 0;
            padding: 0;
            /* Menjadikan body sebagai flex container */
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }

        header {
            background-color: #5a3e2b;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 1rem;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: #d9b08c;
            color: #5a3e2b;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            margin-bottom: 1rem;
            margin-right: 0.5rem; /* Menambah jarak antar tombol */
        }

        .btn:hover {
            background-color: #c4977a;
        }

        /* Style khusus untuk tombol kembali */
        .btn-back {
            background-color: #5a6268;
            color: white;
        }
        .btn-back:hover {
            background-color: #4a5056;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 0.75rem;
            text-align: left;
        }

        th {
            background-color: #f4e1d2;
        }

        footer {
            text-align: center;
            padding: 1rem 0;
            background-color: #5a3e2b;
            color: #fff;
            /* KUNCI: Mendorong footer ke bawah */
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Kelola Pelanggan</h1>
    </header>
    <div class="container">
        <a href="create.php" class="btn">Tambah Pelanggan</a>
        <a href="../index.php" class="btn btn-back">Kembali ke Dashboard</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>No HP</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require_once '../db.php';
                $stmt = $pdo->query("SELECT * FROM pelanggan");
                $pelanggan = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if ($pelanggan):
                    foreach ($pelanggan as $row):
                ?>
                <tr>
                    <td><?= htmlspecialchars($row['id_pelanggan']) ?></td>
                    <td><?= htmlspecialchars($row['nama_pelanggan']) ?></td>
                    <td><?= htmlspecialchars($row['no_hp']) ?></td>
                    <td><?= htmlspecialchars($row['alamat']) ?></td>
                    <td>
                        <a href="edit.php?id=<?= $row['id_pelanggan'] ?>" class="btn">Edit</a>
                        <a href="delete.php?id=<?= $row['id_pelanggan'] ?>" class="btn" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                    </td>
                </tr>
                <?php
                    endforeach;
                else:
                ?>
                <tr>
                    <td colspan="5">Tidak ada data pelanggan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <footer>
        &copy; 2025 Rumah Sepatu Kulit. All Rights Reserved.
    </footer>
</body>
</html>