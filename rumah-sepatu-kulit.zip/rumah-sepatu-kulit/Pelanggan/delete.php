<?php
require_once '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus data pelanggan berdasarkan ID
    $stmt = $pdo->prepare("DELETE FROM pelanggan WHERE id_pelanggan = ?");
    $stmt->execute([$id]);

    header('Location: index.php');
    exit;
} else {
    die("ID pelanggan tidak diberikan.");
}
?>
