<?php
require_once '../db.php';

// Ambil data pelanggan berdasarkan ID dari URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM pelanggan WHERE id_pelanggan = ?");
    $stmt->execute([$id]);
    $pelanggan = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$pelanggan) {
        die("Data pelanggan tidak ditemukan.");
    }
} else {
    die("ID pelanggan tidak diberikan.");
}

// Proses untuk update data saat form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama_pelanggan'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];

    try {
        $stmt = $pdo->prepare("UPDATE pelanggan SET nama_pelanggan = ?, no_hp = ?, alamat = ? WHERE id_pelanggan = ?");
        $stmt->execute([$nama, $no_hp, $alamat, $id]);

        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        die("Terjadi kesalahan: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pelanggan</title>
    <style>
        html {
            height: 100%;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4e1d2;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }
        header {
            background-color: #5a3e2b;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }
        header h1 {
            margin: 0;
        }
        .container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 1.5rem;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 0.75rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
            box-sizing: border-box;
        }
        
        .btn-container {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .btn-update, .btn-back {
            flex: 1;
            padding: 0.75rem;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            text-align: center;
            text-decoration: none;
        }
        .btn-update {
            background-color: #ffc107;
            color: black;
        }
        .btn-update:hover {
            opacity: 0.85;
        }
        .btn-back {
            background-color: #5a6268;
            color: white;
        }
        .btn-back:hover {
            background-color: #4a5056;
        }
        
        footer {
            text-align: center;
            padding: 1rem 0;
            background-color: #5a3e2b;
            color: #fff;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Edit Pelanggan</h1>
    </header>
    <div class="container">
        <form method="POST">
            <label for="nama_pelanggan">Nama Pelanggan</label>
            <input type="text" id="nama_pelanggan" name="nama_pelanggan" value="<?= htmlspecialchars($pelanggan['nama_pelanggan']) ?>" required>

            <label for="no_hp">No HP</label>
            <input type="text" id="no_hp" name="no_hp" value="<?= htmlspecialchars($pelanggan['no_hp']) ?>" required>

            <label for="alamat">Alamat</label>
            <textarea id="alamat" name="alamat" rows="4" required><?= htmlspecialchars($pelanggan['alamat']) ?></textarea>

            <div class="btn-container">
                <a href="index.php" class="btn-back">Kembali</a>
                <button type="submit" class="btn-update">Update</button>
            </div>
        </form>
    </div>
    <footer>
        &copy; 2025 Rumah Sepatu Kulit. All Rights Reserved.
    </footer>
</body>
</html>