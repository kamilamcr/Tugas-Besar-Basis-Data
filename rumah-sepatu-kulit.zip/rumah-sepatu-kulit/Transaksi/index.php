<?php
require_once '../db.php';

try {
    // Query ini mengambil semua transaksi dan menggabungkannya dengan nama pelanggan dan nama kasir.
    $stmt = $pdo->query("
        SELECT 
            t.id_transaksi,
            t.no_pesanan,
            p.nama_pelanggan,
            k.nama_kasir, -- Kolom nama_kasir ditambahkan
            t.tanggal_transaksi,
            t.metode_pembayaran,
            t.jumlah_bayar,
            t.status
        FROM 
            transaksi t
        JOIN 
            pesanan ps ON t.no_pesanan = ps.no_pesanan
        JOIN 
            pelanggan p ON ps.id_pelanggan = p.id_pelanggan
        LEFT JOIN                           -- Menggunakan LEFT JOIN ke tabel kasir
            kasir k ON ps.id_kasir = k.id_kasir
        ORDER BY 
            t.tanggal_transaksi DESC
    ");
    $transaksi_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Terjadi kesalahan saat mengambil data transaksi: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Transaksi</title>
    <style>
        html { height: 100%; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4e1d2; margin: 0; padding: 0; display: flex; flex-direction: column; min-height: 100%; }
        header { background-color: #5a3e2b; color: #fff; padding: 1rem; text-align: center; }
        header h1 { margin: 0; }
        .container { max-width: 1100px; margin: 2rem auto; padding: 1rem; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        table, th, td { border: 1px solid #ccc; }
        th, td { padding: 0.75rem; text-align: left; }
        th { background-color: #f4e1d2; }
        .btn { display: inline-block; padding: 0.5rem 1rem; text-decoration: none; border-radius: 4px; font-weight: bold; margin-bottom: 0.5rem; margin-right: 0.5rem; border: none; cursor: pointer; text-align: center;}
        .btn:hover { opacity: 0.85; }
        .btn-back { background-color: #5a6268; color: white; }
        footer { text-align: center; padding: 1rem 0; background-color: #5a3e2b; color: #fff; margin-top: auto; }
    </style>
</head>
<body>
    <header>
        <h1>Laporan Semua Transaksi</h1>
    </header>
    <div class="container">
        <a href="../index.php" class="btn btn-back">Kembali ke Dashboard</a>
        <table>
            <thead>
                <tr>
                    <th>ID Transaksi</th>
                    <th>No Pesanan</th>
                    <th>Nama Pelanggan</th>
                    <th>Dicatat oleh (Kasir)</th> <th>Tanggal Transaksi</th>
                    <th>Metode Pembayaran</th>
                    <th>Jumlah Bayar</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($transaksi_list)): ?>
                    <?php foreach ($transaksi_list as $transaksi): ?>
                        <tr>
                            <td><?= htmlspecialchars($transaksi['id_transaksi']) ?></td>
                            <td><?= htmlspecialchars($transaksi['no_pesanan']) ?></td>
                            <td><?= htmlspecialchars($transaksi['nama_pelanggan']) ?></td>
                            <td><?= htmlspecialchars($transaksi['nama_kasir'] ?? 'N/A') ?></td> <td><?= htmlspecialchars($transaksi['tanggal_transaksi']) ?></td>
                            <td><?= htmlspecialchars($transaksi['metode_pembayaran']) ?></td>
                            <td>Rp <?= htmlspecialchars(number_format($transaksi['jumlah_bayar'], 0, ',', '.')) ?></td>
                            <td><?= htmlspecialchars($transaksi['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">Tidak ada data transaksi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <footer>
        &copy; 2025 Rumah Produksi "T-DEE". All Rights Reserved.
    </footer>
</body>
</html>